
        var pictureBtn = document.getElementById("pictureBtn");
        var btn = document.getElementById("pic");

        function ChoosePhoto(){
            btn.click();
        }

        let img = document.getElementById("img");
        let button = document.getElementById("pic");

            button.addEventListener("change", function(){
                if(this.files[0].type != "image/jpeg" &&  this.files[0].type != "image/png" && this.files[0].type != "image/gif"){
                    alert("Sorry invalid file type. Please upload an image");
                }
                else{
                    img.style.display = "block";
                    img.src = URL.createObjectURL(this.files[0]);
                }

            });

        var edit_picture = document.getElementById("picture-edit");
        var editbtn = document.getElementById("edit-pic");

        function EditPhoto(){
            editbtn.click();
        }

        let img_change = document.getElementById("img-change");
        let edit_button = document.getElementById("edit-pic");

            edit_button.addEventListener("change", function(){
                if(this.files[0].type != "image/jpeg" &&  this.files[0].type != "image/png" && this.files[0].type != "image/gif"){
                    alert("Sorry invalid file type. Please upload an image");
                }
                else{
                    img_change.style.display = "block"
                    img_change.src = URL.createObjectURL(this.files[0])
                }

            });