<?php
include("../fu/db_conn.php");

$id =mysqli_real_escape_string($mysqli, $_GET['ui']);
$on =mysqli_real_escape_string($mysqli, $_GET['on']);
$user_id = base64_decode($id);
$order_no = base64_decode($on);

$payment_approve = $mysqli->query("UPDATE orders SET delivery_permission = 1 WHERE user_id = '$user_id' AND order_no = '$order_no' LIMIT 1");

if($payment_approve){

    $from_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$user_id'");
        $count = 0;
        if(mysqli_num_rows($from_cart) != 0){

            while($row_from_cart = mysqli_fetch_array($from_cart)){
                $count += 1;
                $product_id = $row_from_cart['product_id'];
                $product_image = $row_from_cart['product_image'];
                $product_name = $row_from_cart['product_name'];
                $quantity = $row_from_cart['quantity'];
                $size = $row_from_cart['size'];

                $to_order_details = $mysqli->query("INSERT INTO order_details (order_no, product_id, product_image, product_name, quantity, size) VALUES ('$order_no', '$product_id', '$product_image', '$product_name', '$quantity', '$size')");
                if($to_order_details){
                    $select_product = $mysqli->query("SELECT * FROM products WHERE id = '$product_id'");
                    if(mysqli_num_rows($select_product) != 0){
                        $row_selected = mysqli_fetch_array($select_product);
                    }
                    if($size == 'Regular'){
                        $new_stock = $row_selected['regular_stock'] - $quantity;
                        $update_stock = $mysqli->query("UPDATE products SET regular_stock = '$new_stock' WHERE id = '$product_id'");
                    }
                   
                    if($size == 'Large'){
                        $new_stock = $row_selected['large_stock'] - $quantity;
                        $update_stock = $mysqli->query("UPDATE products SET large_stock = '$new_stock' WHERE id = '$product_id'");
                    }
                    
                    
                }
           
            }
        }
        if($count == mysqli_num_rows($from_cart)){
            $remove_cart = $mysqli->query("DELETE FROM cart WHERE user_id = '$user_id'");
            if($remove_cart){
                header("Location: trackOrder.php?ui=$id&&on=$on");
            }
        }   
}

?>