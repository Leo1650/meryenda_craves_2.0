<?php
include("../fu/db_conn.php");


    $id =mysqli_real_escape_string($mysqli, $_GET['ui']);
    $user_id = base64_decode($id);

    $check_status = $mysqli->query("SELECT * FROM users WHERE id = '$user_id'");
    if(mysqli_num_rows($check_status) != 0){
        $row_check = mysqli_fetch_array($check_status);
        if($row_check['status'] == 0){
            header("Location: login.php");
            exit();
        }
    }
    
    $select_num_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$user_id'");
    if(mysqli_num_rows($select_num_cart) != 0){
        $total_items = mysqli_num_rows($select_num_cart);
    }else{
        $total_items = 0;
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/index.css">
    <link rel="stylesheet" href="../css/navbar.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <script src="https://kit.fontawesome.com/421b0c86b1.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Homepage</title>
</head>
<body>

<div class="navbar">
        <div class="hamburger" id="hamburger" onclick="show_nav()"><i class="fas fa-bars"></i></div>
        <div class="exit" id="exit" onclick="hide_nav()"><i class="fas fa-times"></i></div>
        <div class="navbar_wrapper">

            <div class="logo">
                <img src="../img/MCLogo.png" alt="Logo">
            </div>

            <div class="link_wrapper" id="links">
                <ul>
                    <li><a href="home.php?ui=<?php echo $id; ?>&&cid=MA==" id="home"><i class="fas fa-home"></i> Home</a></li>
                    <li><a href="product_list.php?ui=<?php echo $id; ?>&&cid=MA==" id="product"><i class="fas fa-tshirt"></i> Shop</a></li>
                    <li><a href="cart.php?ui=<?php echo $id; ?>" id="cart"><i class="fas fa-shopping-cart"></i> Cart<span id="counter"><p><?php echo $total_items; ?></p></span></a></li>
                   
                    <li><a href="trackOrder.php?ui=<?php echo $id; ?>" id="orders"><i class="fas fa-tags"></i> Orders</a></li>

                    <li><a href="../fu/logout_user.php?ui=<?php echo $id; ?>"><i class="fas fa-user-circle"></i> Logout</a></li>

            
                </ul>
            </div>
        </div>
</div>


<div class="banner_wrapper">
    <img src="../img/Banner_MC.jpg" alt="Logo">

      
</div>


<div class="best_seller_section">
        <div class="best_seller_title"><p>Products on Sale</p></div>
        <div class="best_seller_body">
            <div class="all_product_wrapper">

            <?php
                 $select_featured_product = $mysqli->query("SELECT * FROM products WHERE disc !=0 ORDER BY sold desc LIMIT 3");
                if(mysqli_num_rows($select_featured_product) != 0){
                    $default_size = base64_encode('Regular');
                    while($row_featured = mysqli_fetch_array($select_featured_product)){
                        $item_id = base64_encode($row_featured['id']);
                        echo '<div class="product_wrapper">
                            <div class="product_control">
                            <a href="item_page.php?ui='.$id.'&&pid='.$item_id.'&&se='.$default_size.'"><div class="product_img"><img src="../admin/products_img/'.$row_featured['image'].'" alt="Product Picture"></div></a>
                                <div class="details">
                                <div class="product_name">'.$row_featured['name'].'</div>

                                '.(($row_featured['disc'] != 0)?'
                                    <div class="product_prize"><span>&#8369</span> '.$row_featured['regular_price'].' &nbsp; <span style="color: #df313c;">'.$row_featured['disc'].'% off</span></div>
                                    '
                                    :'
                                    <div class="product_prize"><span>&#8369</span> '.$row_featured['regular_price'].'</div>
                                    ').'

                                <div class="product_btn"><a href="item_page.php?ui='.$id.'&&pid='.$item_id.'&&se='.$default_size.'">Buy Now</a></div>
                                </div>
                            </div>
                        </div>';
                    }
                }
            ?>           
                
            </div>
        </div>
    </div>





<div class="best_seller_section">
        <div class="best_seller_title"><p>Popular Products</p></div>
        <div class="best_seller_body">
            <div class="all_product_wrapper">

            <?php
                 $select_featured_product = $mysqli->query("SELECT * FROM products WHERE sold !=0 ORDER BY sold desc LIMIT 3");
                if(mysqli_num_rows($select_featured_product) != 0){
                    $default_size = base64_encode('Regular');
                    while($row_featured = mysqli_fetch_array($select_featured_product)){
                        $item_id = base64_encode($row_featured['id']);
                        echo '<div class="product_wrapper">
                            <div class="product_control">
                            <a href="item_page.php?ui='.$id.'&&pid='.$item_id.'&&se='.$default_size.'"><div class="product_img"><img src="../admin/products_img/'.$row_featured['image'].'" alt="Product Picture"></div></a>
                                <div class="details">
                                <div class="product_name">'.$row_featured['name'].'</div>

                                '.(($row_featured['disc'] != 0)?'
                                    <div class="product_prize"><span>&#8369</span> '.$row_featured['regular_price'].' &nbsp; <span style="color: #df313c;">'.$row_featured['disc'].'% off</span></div>
                                    '
                                    :'
                                    <div class="product_prize"><span>&#8369</span> '.$row_featured['regular_price'].'</div>
                                    ').'

                                <div class="product_btn"><a href="item_page.php?ui='.$id.'&&pid='.$item_id.'&&se='.$default_size.'">Buy Now</a></div>
                                </div>
                            </div>
                        </div>';
                    }
                }
            ?>           
                
            </div>
        </div>
    </div>
    

<div class="best_seller_section">
        <div class="best_seller_title"><p>Featured Products</p></div>
        <div class="best_seller_body">
            <div class="all_product_wrapper">

            <?php
                 $select_featured_product = $mysqli->query("SELECT * FROM products ORDER BY rand() LIMIT 8");
                if(mysqli_num_rows($select_featured_product) != 0){
                    $default_size = base64_encode('Regular');
                    while($row_featured = mysqli_fetch_array($select_featured_product)){
                        $item_id = base64_encode($row_featured['id']);
                        echo '<div class="product_wrapper">
                            <div class="product_control">
                            <a href="item_page.php?ui='.$id.'&&pid='.$item_id.'&&se='.$default_size.'"><div class="product_img"><img src="../admin/products_img/'.$row_featured['image'].'" alt="Product Picture"></div></a>
                                <div class="details">
                                <div class="product_name">'.$row_featured['name'].'</div>

                                '.(($row_featured['disc'] != 0)?'
                                    <div class="product_prize"><span>&#8369</span> '.$row_featured['regular_price'].' &nbsp; <span style="color: #df313c;">'.$row_featured['disc'].'% off</span></div>
                                    '
                                    :'
                                    <div class="product_prize"><span>&#8369</span> '.$row_featured['regular_price'].'</div>
                                    ').'

                                
                                <div class="product_btn"><a href="item_page.php?ui='.$id.'&&pid='.$item_id.'&&se='.$default_size.'">Buy Now</a></div>
                                </div>
                            </div>
                        </div>';
                    }
                }
            ?>           
                
            </div>
        </div>
    </div>


     <script>
        let hamburger = document.getElementById('hamburger');
        let exit = document.getElementById('exit');
        let links = document.getElementById('links');

        function show_nav(){
            hamburger.style.display = "none";
            exit.style.display = "block";
            links.style.left = '0';
        }
        function hide_nav(){
            hamburger.style.display = "block";
            exit.style.display = "none";
            links.style.left = '-100%';
        }
        var options = document.getElementById('options');
        function show_options(){
            options.style.display = "block";
        }
        function hide_options(){
            options.style.display = "none";
        }
        var profile = document.getElementById('drop_profile');
        function show_profile(){
            profile.style.display = "block";
        }
        function hide_profile(){
            profile.style.display = "none";
        }

      
    </script>
</body>
</html>

<?php
include("footer.php");
?>
