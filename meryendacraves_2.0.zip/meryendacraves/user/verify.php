<?php
include('../fu/db_conn.php');

$vkey =mysqli_real_escape_string($mysqli, $_GET['vkey']);
$update = $mysqli->query("UPDATE users SET verified= 1 WHERE verification_key ='$vkey'");

if($update){
    header("Location: login.php");
}else{
    echo "false";
}
?>

