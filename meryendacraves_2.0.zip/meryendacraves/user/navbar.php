<?php
include("../fu/db_conn.php");
session_start();
$id =mysqli_real_escape_string($mysqli, $_GET['ui']);
$user_id = base64_decode($id);

$check_status = $mysqli->query("SELECT * FROM users WHERE id = '$user_id'");
if(mysqli_num_rows($check_status) != 0){
    $row_check = mysqli_fetch_array($check_status);
    if($row_check['status'] == 0){
        header("Location: login.php");
        exit();
    }
}



$select_num_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$user_id'");
if(mysqli_num_rows($select_num_cart) != 0){
    $total_items = mysqli_num_rows($select_num_cart);
}else{
    $total_items = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/navbar.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <script src="https://kit.fontawesome.com/421b0c86b1.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="navbar">
        <div class="hamburger" id="hamburger" onclick="show_nav()"><i class="fas fa-bars"></i></div>
        <div class="exit" id="exit" onclick="hide_nav()"><i class="fas fa-times"></i></div>
        <div class="navbar_wrapper">

            <div class="logo">
                <img src="../img//MCLogo.png" alt="Logo">
            </div>

            <div class="link_wrapper" id="links">
                <ul>
                    <?php
                        if(!isset($_SESSION['guessID'])){
                    ?>
                            <li><a href="home.php?ui=<?php echo $id; ?>&&cid=MA==" id="home"><i class="fas fa-home"></i> Home</a></li>
                    <?php
                        }else{
                    ?>
                            <li><a href="../" id="home"><i class="fas fa-home"></i> Home</a></li>
                    <?php
                        }
                    ?>
                    <li><a href="product_list.php?ui=<?php echo $id; ?>&&cid=MA==" id="product"><i class="fas fa-tshirt"></i> Shop</a></li>
                    <li><a href="cart.php?ui=<?php echo $id; ?>" id="cart"><i class="fas fa-shopping-cart"></i> Cart<span id="counter"><p><?php echo $total_items; ?></p></span></a></li>


                    <?php
                        if(!isset($_SESSION['guessID'])){
                    ?>
                            <li><a href="trackOrder.php?ui=<?php echo $id; ?>" id="orders"><i class="fas fa-tags"></i> Orders</a></li>

                            <li><a href="../fu/logout_user.php?ui=<?php echo $id; ?>"><i class="fas fa-user-circle"></i> Logout</a></li>
                    <?php
                        }else{
                    ?>
                            <li><a href="login.php"><i class="fas fa-sign-in-alt"></i> Sign in</a></li>
                    <?php
                        }
                    ?>
                </ul>
            </div>
        </div>
    </div>

    

    

    <script>
        let hamburger = document.getElementById('hamburger');
        let exit = document.getElementById('exit');
        let links = document.getElementById('links');

        function show_nav(){
            hamburger.style.display = "none";
            exit.style.display = "block";
            links.style.left = '0';
        }
        function hide_nav(){
            hamburger.style.display = "block";
            exit.style.display = "none";
            links.style.left = '-60%';
        }
        var options = document.getElementById('options');
        function show_options(){
            options.style.display = "block";
        }
        function hide_options(){
            options.style.display = "none";
        }
        var profile = document.getElementById('drop_profile');
        function show_profile(){
            profile.style.display = "block";
        }
        function hide_profile(){
            profile.style.display = "none";
        }

      
    </script>
</body>
</html>