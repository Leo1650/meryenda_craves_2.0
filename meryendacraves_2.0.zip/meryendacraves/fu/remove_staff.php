<?php
include("db_conn.php");
session_start();
    $id =mysqli_real_escape_string($mysqli, $_GET['sid']);

    $delete_staff = $mysqli->query("DELETE FROM admin_staff WHERE id = '$id'");
if($delete_staff){
    $_SESSION['message'] = "<div class='success_message'>Deleted</div>";
    header("Location: ../admin/staff_page.php");
}else{
    echo "Failed";
}


?>