<?php
    $host = "localhost";
    $dbUsername = "u481024253_mczcdb";
    $dbPassword = "u481024253MCZCdb";
    $dbName = "u481024253_meryendacraves";
    $mysqli = new mysqli($host, $dbUsername, $dbPassword, $dbName);
?>