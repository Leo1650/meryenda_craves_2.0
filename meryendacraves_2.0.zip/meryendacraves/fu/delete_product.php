<?php
include("db_conn.php");
session_start();
    $id =mysqli_real_escape_string($mysqli, $_GET['pid']);

    $delete = $mysqli->query("DELETE FROM products WHERE id = '$id'");
if($delete){
    $_SESSION['message'] = "<div class='success_message'>Deleted</div>";
    header('Location: ../admin/products&category.php?pid=&&cid=');
}else{
    echo "Failed";
}


?>