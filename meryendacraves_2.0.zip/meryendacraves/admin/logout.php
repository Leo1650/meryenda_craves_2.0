<?php
include("../fu/db_conn.php");

$select_admin = $mysqli->query("SELECT * FROM admin_accs");
if(mysqli_num_rows($select_admin) != 0){
    $logout = $mysqli->query("UPDATE admin_accs SET status = 0");

    if($logout){
        header("Location: ../index.php");
    }
}



?>