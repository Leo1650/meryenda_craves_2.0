<?php
include("../fu/db_conn.php");
include("sidebar.php");
session_start();

$cid =mysqli_real_escape_string($mysqli, $_GET['cat']);
$c_id = base64_decode($cid);

$pid =mysqli_real_escape_string($mysqli, $_GET['pid']);
$p_id = base64_decode($pid);


$selected_category = $mysqli->query("SELECT * FROM categories WHERE id = '$c_id'");
if(mysqli_num_rows($selected_category) != 0){
    $row_selected_cat = mysqli_fetch_array($selected_category);
}else{
    $row_selected_cat['name'] = '';
}




 



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/inventory.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <title>Inventory</title>
</head>
<body>
    <div class="title">
        <h1><?php echo $row_selected_cat['name']; ?></h1>
        <select name="category" id="select_cat">
                        <?php
                            
                            $all_category = $mysqli->query("SELECT * FROM categories");
                            if(mysqli_num_rows($all_category) != 0){
                                echo '<option value="'.$row_selected_cat['id'].'">'.$row_selected_cat['name'].'</option>';
                                while($row_all_cat = mysqli_fetch_array($all_category)){
        
                                    if($c_id != $row_all_cat['id']){
                                        echo '<option value="'.$row_all_cat['id'].'">'.$row_all_cat['name'].'</option>';
                                    }else{
                                        //don't display
                                    }
                                                
                                }
                            }else{
                                echo '<option>No Category</option>';
                            } 
                        ?>
                            </select>
    </div>
    
    <div class="content_body">
        <div class="products_section" id="inventory_section">

                <div class="product_table" id="inventory_table">
                    <table class="tables" id="inventory_download">
                        <thead>
                            <tr>
                                <th class="product_name">Name</th>
                                <th class="product_regular">Regular</th>
                                <th class="product_large">Medium</th>
                                <th class="product_large">Large</th>
                                <th class="product_large">XL</th>
                               
                               
                               
                                <th class="product_category">Total Available Stocks</th>
                           
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $c_id = base64_decode($cid);
                                $select_all_products = $mysqli->query("SELECT * FROM products WHERE category = '$c_id'");
                                
                                if(mysqli_num_rows($select_all_products) != 0){
                                
                                    while($row_product = mysqli_fetch_array($select_all_products)){
                                        $prod_id = base64_encode($row_product['id']);
                                        $total_stock = $row_product['regular_stock'] + $row_product['large_stock'];
                                        echo '<tr>
                                        <td class="product_name">'.$row_product['name'].'</td>
        
                                        <td class="product_regular">
                                            <span>'.$row_product['regular_stock'].'</span>
                                        </td>
                                        
                                        <td class="product_large">
                                            <span>'.$row_product['medium_stock'].'</span>
                                        </td>
        
                                        <td class="product_large">
                                            <span>'.$row_product['large_stock'].'</span>
                                        </td>

                                        <td class="product_large">
                                            <span>'.$row_product['xl_stock'].'</span>
                                        </td>

                                        
                                    </td>
        
                                       
        
                                        <td class="product_category">
                                            <span>'.$total_stock.'</span>
                                        </td>
        
                                                                          
                                        
                                        </tr>';
                                    }
                                }else{
                                    echo '<tr>
                                            <td colspan=6 style="text-align: center; color: grey;">No products for this categoryy</td>
                                        </tr>';
                                }


                            ?>
                                                 
                        </tbody>
                    </table>
                </div>

           
        </div>

        
    </div> 
   

    <?php
        if(isset($_SESSION['message'])){
            echo $_SESSION['message'];
            unset($_SESSION['message']);
        }
    ?>

    <script src="../js/inventory.js"></script>

    <script type="text/javascript" src="../src/jquery-3.3.1.slim.min.js"></script>

    <script type="text/javascript" src="../src/jspdf.min.js"></script>

    <script type="text/javascript" src="../src/jspdf.plugin.autotable.min.js"></script>

    <script type="text/javascript" src="../src/tableHTMLExport.js"></script>

    <script type="text/javascript">

    $("#download").on("click",function(){
        $("#inventory_download").tableHTMLExport({
        type:'pdf',
        filename:'inventory.pdf'
        });
    });
    </script>
</body>
</html>